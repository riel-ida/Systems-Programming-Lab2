#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct fun_desc {
  char *name;
  char (*fun)(char);
};

char censor(char c) {
  if(c == '!')
    return '.';
  else
    return c;
}
 
char* map(char *array, int array_length, char (*f) (char)){
  char* mapped_array = (char*)(malloc(array_length*sizeof(char)));
  
  for(int i=0; i<array_length; i++)
  {
      *(mapped_array+i) = (*f)(*(array+i));
  }
  return mapped_array;
}

char encrypt(char c){
    if(c>0x20 && c<0x7E) return c+3;
    else return c;
}

char decrypt(char c){
    if(c>0x20 && c<0x7E) return c-3;
    else return c;
}

char xprt(char c){
    printf("%#04x\n", c);
    return c;
}

char cprt(char c){
    if(c>0x20 && c<0x7E) printf("%c\n", c);
    else if((c<0x20) | (c>0x7E) | (c == '\n')) printf(".\n");
    return c;
}

char my_get(char c){
    char ch = fgetc(stdin);
    return ch;
}

char quit(char c){
    exit(0);
}
 
int main(int argc, char **argv){
    //char carray[5] = {0, 0, 0, 0, 0};
    int func_num;
    struct fun_desc menu[] = { { "censor", &censor }, { "encrypt", &encrypt }, { "decrypt", &decrypt }, { "xprt", &xprt }, 
                                { "cprt", &cprt }, { "my_get", &my_get },{  "quit", &quit }, { NULL, NULL } };
    
    printf("Please choose a function:\n");
    for(int i = 0; i < (sizeof(menu)/sizeof(struct fun_desc))-1; i++){
        printf("%d) %s\n", i, menu[i].name);
    }
    printf("Option: ");
    scanf("%d", &func_num);
    if(func_num >= 0 && func_num <=6) printf("Within bounds\n");
    else{
        printf("Not within bounds\n");
        exit(0);
    }
    
    return 0;
}